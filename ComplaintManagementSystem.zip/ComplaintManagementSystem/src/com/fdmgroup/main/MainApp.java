package com.fdmgroup.main;

import com.fdmgroup.dao.ReplyDao;
import com.fdmgroup.dao.TicketDao;
import com.fdmgroup.dao.UserDao;
import com.fdmgroup.model.AdminUser;
import com.fdmgroup.model.Reply;
import com.fdmgroup.model.Ticket;
import com.fdmgroup.model.TicketStatus;
import com.fdmgroup.model.User;



public class MainApp {

	public static void main(String[] args) {
		
		// make two users	
		User u1 = new User("yym", "ihatefaires", "Captain James", "123456789","g@gmail.com","123","123");
		User u2 = new User("smee99", "lostboyssmell", "Smee", "5146666666","1@gmail.com","123","123");
				
		// add two users
		UserDao userDao = new UserDao();
		userDao.create(u1);
		userDao.create(u2);
		System.out.println("2 USERS ADDED!");
	
		// make one admin 
		AdminUser a1 = new AdminUser("admin", "admin");
		
		// add one admin
		userDao.create(a1);
		System.out.println("ADMIN ADDED!");
		

		
		// make one ticket, created by user1
		Ticket ticket1 = new Ticket();
		TicketStatus status1 = TicketStatus.NEW;
		ticket1.setContentCreated("First content.");
		ticket1.setCreatedBy(u1);
		ticket1.setCreatedTime();
		ticket1.setTicketStatus(status1);
		
		// make one reply, created by admin
		Reply reply1 = new Reply();
		reply1.setReplyContent("First reply.");
		reply1.setTicket(ticket1);
		reply1.setReplyBy(a1);
		
		// add ticket
				TicketDao ticketDao = new TicketDao();
				ticketDao.addTicket(ticket1);
				System.out.println("Table Ticket Created!");
				
		
		// add reply
		ReplyDao replyDao = new ReplyDao();
		replyDao.addReply(reply1);
		System.out.println("Table Reply Created!");
				
	
		
		System.out.println("END");
	}
	
}
