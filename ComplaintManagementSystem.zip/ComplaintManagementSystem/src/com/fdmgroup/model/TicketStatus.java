package com.fdmgroup.model;

public enum TicketStatus {
	NEW,
	OPEN,
	CLOSED
}
