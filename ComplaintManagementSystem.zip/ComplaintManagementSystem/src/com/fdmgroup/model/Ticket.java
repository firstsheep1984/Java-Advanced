package com.fdmgroup.model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Ticket")
//@NamedQueries({
//	@NamedQuery(name="t.findByName",query="SELECT t FROM Team t WHERE t.teamName = :tName")
//})
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ticket_id")
	private int ticketId;
	
	@Column
	private String contentCreated;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id")
	private User createdBy;
	
	@Column
	private LocalDate createdTime;
	
	@OneToMany(mappedBy="ticket")
	private List<Reply> replyList;
	
//	@OneToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "ticketId")
//	private Ticket ticket;
	
	@Column
	TicketStatus ticketStatus;
	
	public String getContentCreated() {
		return contentCreated;
	}
	public void setContentCreated(String contentCreated) {
		this.contentCreated = contentCreated;
	}
	public User getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	public LocalDate getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime() {
		createdTime =  LocalDate.now();
	}
		
	public List<Reply> getReplyList() {
		return replyList;
	}
	public void setReplyList(List<Reply> replyList) {
		this.replyList = replyList;
	}
	public int getTicketId() {
		return ticketId;
	}
	
	
	public TicketStatus getTicketStatus() {
		return ticketStatus;
	}
	public void setTicketStatus(TicketStatus ticketStatus) {
		this.ticketStatus = ticketStatus;
	}
	@Override
	public String toString() {
		return "Ticket [ticketId=" + ticketId + ", contentCreated=" + contentCreated + ", createdTime=" + createdTime + ",  ticketStatus=" + ticketStatus + "]";
	}
	
	
		
	
}

