package com.fdmgroup.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
/*@NamedQueries({
	@NamedQuery(name = "a.findAllAdmin", query = "SELECT a FROM AdminUser a")
	//@NamedQuery(name = "a.findAdmin", query = "SELECT a FROM AdminUser a where a.privilege = :aprivilege")
})*/
public class AdminUser extends User {
	
	
	
	public AdminUser() {
		super();
	}

	
	public AdminUser(String username, String password) {
		super(username, password);
		this.setPrivilege("ADMIN");
	}


	
}
