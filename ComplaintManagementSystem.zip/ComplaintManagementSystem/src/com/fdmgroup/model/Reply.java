package com.fdmgroup.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_REPLY")
//@NamedQueries({
//	@NamedQuery(name = "company.findByName", query = "SELECT c FROM Company c WHERE c.name LIKE :cn"),
//})
public class Reply {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "reply_id")
	private int replyId;
	
	@Column
	private String replyContent;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id")
	private User replyBy;
	
	@Column
	private LocalDate replyTime;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="contentId")
	private Ticket ticket;
	
	public String getReplyContent() {
		return replyContent;
	}
	public void setReplyContent(String replyContent) {
		this.replyContent = replyContent;
	}
	public User getReplyBy() {
		return replyBy;
	}
	public void setReplyBy(User replyBy) {
		this.replyBy = replyBy;
	}
	public LocalDate getReplyTime() {
		replyTime = LocalDate.now();
		return replyTime;
	}
	public void setReplyTime(LocalDate replyTime) {
		this.replyTime = replyTime;
	}
	public int getReplyId() {
		return replyId;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	@Override
	public String toString() {
		return "Reply [replyId=" + replyId + ", replyContent=" + replyContent + ", replyTime="
				+ replyTime + "]";
	}
	

	
	
}
