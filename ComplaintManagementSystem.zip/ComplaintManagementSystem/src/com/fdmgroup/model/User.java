package com.fdmgroup.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;


@Entity
@Table(name = "COMPLAINT_USER")
@NamedQueries({
	@NamedQuery(name="u.findByUserID", query="SELECT u FROM User u WHERE u.user_id = :uIDParam"),
	@NamedQuery(name = "u.findAll", query = "SELECT u FROM User u"),
	@NamedQuery(name = "u.findByUsername", query = "SELECT u FROM User u where u.username = :uname")
})
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class User {
	
	@Id
	@SequenceGenerator(name = "userSeq", sequenceName = "USER_MBG",  initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "userSeq")
	@Column(name = "user_id")	
	private int user_id;
	
	@Column(name="INH_COL_PRIV")
	private String privilege;
	
	@Column(name = "userNameColumn", length = 30, nullable = false, unique = true)
	private String username;
	
	@Column
	private String firstname;
	
	@Column
	private String lastname;
	
	@Column
	private String phoneNumber;
	
	@Column
	private String email;
	
	@Column(name = "pw", length = 30)
	private String password;
		
	@Column(name = "re_pw", length = 30)
	private String rePassword;
	
	@OneToMany(mappedBy="replyBy")
	private List<Reply> replyList;
	
	@OneToMany(mappedBy="createdBy")
	private List<Ticket> ticketList;
	
	public User() {
		super();
	}
	
	public User(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}

	public User(String username, String firstname, String lastname, String phoneNumber, String email, String password,
			String rePassword) {
		super();
		this.username = username;
		this.firstname = firstname;
		this.lastname = lastname;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.password = password;
		this.rePassword = rePassword;
	}


	
	public String getPrivilege() {
		return privilege;
	}

	public void setPrivilege(String privilege) {
		this.privilege = privilege;
	}

	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getFirstname() {
		return firstname;
	}


	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}


	public String getLastname() {
		return lastname;
	}


	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRePassword() {
		return rePassword;
	}


	public void setRePassword(String rePassword) {
		this.rePassword = rePassword;
	}


	public int getId() {
		return user_id;
	}


	public List<Reply> getReplyList() {
		return replyList;
	}

	public void setReplyList(List<Reply> replyList) {
		this.replyList = replyList;
	}

	public List<Ticket> getTicketList() {
		return ticketList;
	}

	public void setTicketList(List<Ticket> ticketList) {
		this.ticketList = ticketList;
	}

	public int getUser_id() {
		return user_id;
	}

	@Override
	public String toString() {
		return "User [user_id=" + user_id + ", username=" + username + ", firstname=" + firstname + ", lastname="
				+ lastname + ", phoneNumber=" + phoneNumber + ", email=" + email + ", password=" + password
				+ ", rePassword=" + rePassword + ", replyList=" + replyList + ", ticketList=" + ticketList + "]";
	}

	

	
}
