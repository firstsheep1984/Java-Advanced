package com.fdmgroup.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fdmgroup.dao.TicketDao;
import com.fdmgroup.dao.UserDao;
import com.fdmgroup.model.Reply;
import com.fdmgroup.model.Ticket;
import com.fdmgroup.model.TicketStatus;
import com.fdmgroup.model.User;


public class SearchServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String searchWord = request.getParameter("searchBar");
		
		UserDao userDao1 = new UserDao();
		TicketDao ticketDao = new TicketDao();
		
		HttpSession session = request.getSession();
		User loggedInUser= (User) session.getAttribute("mbgUserLoggedInSession");
		
		User managedUser = userDao1.findById(loggedInUser.getId());
		
		System.out.println(loggedInUser.getFirstname());
		
		//if(managedUser.getPrivilege() != null) {
			
			List<User> userList = userDao1.findAll();
									
			List<Ticket> sendTicketList= new ArrayList<Ticket>();
			
			for(User u: userList) {
				List<Ticket> ticketList = u.getTicketList();
				for(Ticket t: ticketList) {
					System.out.println(t);
					
					List<Reply> replyList = t.getReplyList();
										
					if(t.getContentCreated()!= null && t.getContentCreated().contains(searchWord)) {
												
						System.out.println("found!");
						Ticket tFound = ticketDao.findById(t.getTicketId());
						System.out.println(tFound);
						sendTicketList.add(tFound);						
					}
					
					for(Reply r : replyList) {
						if(r.getReplyContent()!=null && r.getReplyContent().contains(searchWord)) {
							Ticket tFound = ticketDao.findById(t.getTicketId());
							sendTicketList.add(tFound);							
						}
					}
					
				}
			}

		for(Ticket t : sendTicketList) {
				System.out.println(t);
			}
			
			request.setAttribute("sendTicketList", sendTicketList);
					RequestDispatcher rd = request.getRequestDispatcher("./admin-search.jsp");
			rd.forward(request, response);
			
		/*}
		else {
			System.out.println("I'm a user");
		List<Ticket> userTickets = managedUser.getTicketList();
		
		request.setAttribute("UserTickets", userTickets);
		
			
			RequestDispatcher rd = request.getRequestDispatcher("./user-dashboard.jsp");
			rd.forward(request, response);
		
		}*/

	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

}
