package com.fdmgroup.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fdmgroup.dao.TicketDao;
import com.fdmgroup.dao.UserDao;
import com.fdmgroup.model.Reply;
import com.fdmgroup.model.Ticket;
import com.fdmgroup.model.TicketStatus;
import com.fdmgroup.model.User;


public class EditCloseTicketServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// get param from web form
		String buttonType = request.getParameter("buttontype");
		 if(buttonType.equals("close")) {
			int ticketId = Integer.parseInt(request.getParameter("id"));
		
		
		TicketDao ticketDao = new TicketDao();
		Ticket ticketClose=ticketDao.findById(ticketId);
		TicketStatus status = TicketStatus.CLOSED;
		ticketClose.setTicketStatus(status);
		
		ticketDao.update(ticketClose);
		
		
		System.out.println("Ticket closed!");
		
		RequestDispatcher rd = request.getRequestDispatcher("/ShowTickets");
		rd.forward(request, response);
		}
		else if(buttonType.equals("edit")) {
			int ticketId = Integer.parseInt(request.getParameter("id"));
		
		
		TicketDao ticketDao = new TicketDao();
		Ticket ticketEdit=ticketDao.findById(ticketId);
		
		request.setAttribute("ticketInfo",ticketEdit);
		HttpSession session = request.getSession();
		session.setAttribute("ticketSessionInfo",ticketEdit);
		
		System.out.println("Ticket editing!");
		
		RequestDispatcher rd = request.getRequestDispatcher("edit_ticket.jsp");
		rd.forward(request, response);
		}
		else if(buttonType.equals("adminEdit")) {
			int ticketId = Integer.parseInt(request.getParameter("id"));
		
		
		TicketDao ticketDao = new TicketDao();
		Ticket ticketEdit=ticketDao.findById(ticketId);
		
		request.setAttribute("ticketInfo",ticketEdit);
		HttpSession session = request.getSession();
		session.setAttribute("ticketSessionInfo",ticketEdit);
		
		System.out.println("Ticket editing!");
		
		RequestDispatcher rd = request.getRequestDispatcher("admin_edit_ticket.jsp");
		rd.forward(request, response);
		}
		else {
			System.out.println("Ticket replied!");
			
			RequestDispatcher rd = request.getRequestDispatcher("/editTicket");
			rd.forward(request, response);
			
		}
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req,resp);
	}

}