package com.fdmgroup.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fdmgroup.dao.TicketDao;
import com.fdmgroup.dao.UserDao;
import com.fdmgroup.model.Ticket;
import com.fdmgroup.model.TicketStatus;
import com.fdmgroup.model.User;


public class ShowTicketsServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		UserDao userDao1 = new UserDao();
		
		HttpSession session = request.getSession();
		User loggedInUser= (User) session.getAttribute("mbgUserLoggedInSession");
		
		User managedUser = userDao1.findById(loggedInUser.getId());
		
		if(managedUser.getPrivilege() != null) {
			
			List<User> userList = userDao1.findAll();
			request.setAttribute("UserList", userList);
					RequestDispatcher rd = request.getRequestDispatcher("./admin-dashboard.jsp");
			rd.forward(request, response);
			
		}
		else {
		List<Ticket> userTickets = managedUser.getTicketList();
		
		request.setAttribute("UserTickets", userTickets);
		
			
			RequestDispatcher rd = request.getRequestDispatcher("./user-dashboard.jsp");
			rd.forward(request, response);
		
		}

	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

}