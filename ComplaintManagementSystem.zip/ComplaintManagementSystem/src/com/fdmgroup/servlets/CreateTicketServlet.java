package com.fdmgroup.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fdmgroup.dao.TicketDao;
import com.fdmgroup.dao.UserDao;
import com.fdmgroup.model.Ticket;
import com.fdmgroup.model.TicketStatus;
import com.fdmgroup.model.User;

@WebServlet("/CreateTicketServlet")
public class CreateTicketServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// get param from web form
		String input_content = request.getParameter("newContent");
		
		
		// instantiate a ticket
		Ticket ticket = new Ticket();
		ticket.setContentCreated(input_content);
		
		TicketStatus status = TicketStatus.NEW;
		ticket.setTicketStatus(status);
		
		ticket.setCreatedTime();
		
		UserDao userDao1 = new UserDao();
		
		HttpSession session = request.getSession();
		User loggedInUser= (User) session.getAttribute("mbgUserLoggedInSession");
		
		User managedUser = userDao1.findById(loggedInUser.getId());
		
		ticket.setCreatedBy(managedUser);
				
		
		// validate the content and add ticket to database
		if (!input_content.equals("")) {
			TicketDao ticketDao = new TicketDao();
			ticketDao.addTicket(ticket);
			
			// add ticket to the current user
			/*List<Ticket> currentUserTickets = loggedInUser.getTicketList();
			currentUserTickets.add(ticket);
			
			// update current user
			userDao1.update(loggedInUser);*/
			
			/*loggedInUser.getTicketList().add(ticket);*/
			System.out.println("Ticket added to user");
					
			/*RequestDispatcher rd = request.getRequestDispatcher("/ShowTickets");
			rd.forward(request, response);*/
		} // if no - bounce back to index.jsp w/ error msg
		else {
			request.setAttribute("invalidUsername", "Please input the content ...");
			/*RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);*/
		}
			
		RequestDispatcher rd = request.getRequestDispatcher("/ShowTickets");
		rd.forward(request, response);
	}
	

}