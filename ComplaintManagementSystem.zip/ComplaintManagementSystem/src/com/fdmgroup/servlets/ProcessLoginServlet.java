package com.fdmgroup.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fdmgroup.dao.UserDao;
import com.fdmgroup.model.AdminUser;
import com.fdmgroup.model.User;

@WebServlet("/ProcessLoginServlet")
public class ProcessLoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// get param from web form
		String mbgInputParam = request.getParameter("username");
		String input_password = request.getParameter("password");

		// validate
		UserDao userDao1 = new UserDao();
		List<User> userList = new ArrayList<>();

		userList = userDao1.findAll();
		for(User u: userList) {
			System.out.println(u);
		}
		System.out.println(mbgInputParam);

		boolean isFound = false;
		int foundID = -1;
		
		for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUsername().equals(mbgInputParam) && userList.get(i).getPassword().equals(input_password)) {
				isFound = true;
				foundID = userList.get(i).getId();
			}
		}
		
		// if yes - forward to splash
		User userLoggedIn = null;
	
		
		if (isFound) {
			userLoggedIn = userDao1.findByUserID(foundID);
			
			System.out.println(userLoggedIn);
			
			HttpSession session = request.getSession();
			session.setAttribute("mbgUserLoggedInSession", userLoggedIn);
			session.setMaxInactiveInterval(5000);
			
			RequestDispatcher rd = request.getRequestDispatcher("/ShowTickets");
			rd.forward(request, response);

		} // if no - bounce back to index.jsp w/ error msg
		else {
			request.setAttribute("invalidUsername", "INVALID LOG IN ATTEMPT ...");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}
	}

}
