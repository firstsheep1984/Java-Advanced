package com.fdmgroup.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.fdmgroup.dao.UserDao;
import com.fdmgroup.model.User;

public class EditProfileServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// get param from web form
		String input_username = request.getParameter("username");
		String input_firstname = request.getParameter("firstname");
		String input_lastname = request.getParameter("lastname");
		String input_phonenumber = request.getParameter("phonenumber");
		String input_email = request.getParameter("email");
		String input_password = request.getParameter("password");
		String input_repassword = request.getParameter("repassword");
		
		
		// validate no duplicate username
		UserDao userDao1 = new UserDao();
		List<User> userList = new ArrayList<>();

		userList = userDao1.findAll();
		
		/*for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUsername().equals(input_username) ) {
				request.setAttribute("invalidUsername", "This username already exists ...");
				
				RequestDispatcher rd = request.getRequestDispatcher("edit_profile.jsp");
				rd.forward(request, response);
				
				
			}
		}
		*/
		HttpSession session = request.getSession();
		User loggedInUser= (User) session.getAttribute("mbgUserLoggedInSession");
		
		User managedUser = userDao1.findById(loggedInUser.getId());
		
		if(!input_password.equals(input_repassword)) {
			
			request.setAttribute("invalidUsername", "Password doesn't match!");
			RequestDispatcher rd = request.getRequestDispatcher("edit_profile.jsp");
			rd.forward(request, response);
		}
		// validate no vacant input		
		else if(input_username.equals("") || input_firstname.equals("") || input_lastname.equals("") || 
				input_phonenumber.equals("") && input_email.equals("") && input_password.equals("")){
			request.setAttribute("invalidUsername", "Please fill in all the fields");
			
			RequestDispatcher rd = request.getRequestDispatcher("edit_profile.jsp");
			rd.forward(request, response);
		}
		else {
			managedUser.setUsername(input_username);
			managedUser.setFirstname(input_firstname);
			managedUser.setLastname(input_lastname);
			managedUser.setPhoneNumber(input_phonenumber);
			managedUser.setEmail(input_email);
			managedUser.setPassword(input_password);
			managedUser.setRePassword(input_repassword);
			
			// add to dao
			userDao1.update(managedUser);
			
			System.out.println(managedUser);
			
			request.setAttribute("invalidUsername", "You have updated your profile!");
			RequestDispatcher rd = request.getRequestDispatcher("edit_profile.jsp");
			rd.forward(request, response);
		}

	}
	

}
