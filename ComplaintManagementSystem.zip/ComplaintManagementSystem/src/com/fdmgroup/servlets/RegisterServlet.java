package com.fdmgroup.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.fdmgroup.dao.UserDao;
import com.fdmgroup.model.User;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// get param from web form
		String input_username = request.getParameter("username");
		String input_firstname = request.getParameter("firstname");
		String input_lastname = request.getParameter("lastname");
		String input_phonenumber = request.getParameter("phonenumber");
		String input_email = request.getParameter("email");
		String input_password = request.getParameter("password");
		String input_repassword = request.getParameter("repassword");
		
		// instantiate a user
				User newUser = new User();
				
		// validate no duplicate username
		UserDao userDao1 = new UserDao();
		List<User> userList = new ArrayList<>();

		userList = userDao1.findAll();
		
		for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUsername().equals(input_username) ) {
				request.setAttribute("invalidUsername", "This username already exists ...");
				RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
				rd.forward(request, response);
			}
		}
		
		
		// validation password
		if(!input_password.equals(input_repassword)) {
			request.setAttribute("invalidUsername", "Password doesn't match!");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}
		else if(input_username.equals("") || input_firstname.equals("") || input_lastname.equals("") || 
				input_phonenumber.equals("") && input_email.equals("") && input_password.equals("")){
			request.setAttribute("invalidUsername", "Please fill in all the fields!");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}
		// validate no vacant input
		else 
			/*if(input_username != null && input_firstname != null && input_lastname != null
				&& input_phonenumber != null && input_email != null && input_password != null) */
			{
			newUser.setUsername(input_username);
			newUser.setFirstname(input_firstname);
			newUser.setLastname(input_lastname);
			newUser.setPhoneNumber(input_phonenumber);
			newUser.setEmail(input_email);
			newUser.setPassword(input_password);
			newUser.setRePassword(input_repassword);
			
			// add to dao
			userDao1.create(newUser);
			
			System.out.println(newUser);
			
			HttpSession session = request.getSession();
			session.setAttribute("mbgUserLoggedInSession", newUser);
			session.setMaxInactiveInterval(5000);

			RequestDispatcher rd = request.getRequestDispatcher("/ShowTickets");
			rd.forward(request, response);
		}
		

	}
	

}
