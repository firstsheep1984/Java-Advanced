package com.fdmgroup.servlets;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fdmgroup.dao.ReplyDao;
import com.fdmgroup.dao.TicketDao;
import com.fdmgroup.dao.UserDao;
import com.fdmgroup.model.Reply;
import com.fdmgroup.model.Ticket;
import com.fdmgroup.model.TicketStatus;
import com.fdmgroup.model.User;


public class ReplyServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// get param from web form
		String input_reply = request.getParameter("reply");
		HttpSession session = request.getSession();
				
				
		User loggedInUser= (User) session.getAttribute("mbgUserLoggedInSession");
		
		UserDao userDao1 = new UserDao();
		User managedUser = userDao1.findById(loggedInUser.getId());
				
		if (!input_reply.equals("")) {
		Reply newReply = new Reply();
		newReply.setReplyContent(input_reply);
		newReply.setReplyBy(managedUser);
		newReply.setReplyTime(LocalDate.now());
		
		Ticket currentTicket = (Ticket)session.getAttribute("ticketSessionInfo");
		//Ticket currentTicket = (Ticket)request.getAttribute("ticketInfo");
		TicketDao ticketDao = new TicketDao();
		Ticket managedTicket = ticketDao.findById(currentTicket.getTicketId());
				
		newReply.setTicket(managedTicket);
		
		/*List<Reply> replyList = managedTicket.getReplyList();
		replyList.add(newReply);*/
		
		ReplyDao replyDao = new ReplyDao();
		replyDao.addReply(newReply);
		
		System.out.println("reply added to ticket!");
		
		//asynchronous
		ServletContext sc = request.getServletContext();
		
		String currentMessages = (String) sc.getAttribute("messages");
        sc.setAttribute("messages",  currentMessages);
        
		request.setAttribute("notification", newReply);
		

		}
		else {
			request.setAttribute("invalidUsername", "Please input the reply ...");
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("/ShowTickets");
		rd.forward(request, response);
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
}