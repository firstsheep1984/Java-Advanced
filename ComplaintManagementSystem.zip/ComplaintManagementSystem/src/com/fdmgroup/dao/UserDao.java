package com.fdmgroup.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.fdmgroup.model.AdminUser;
import com.fdmgroup.model.Ticket;
import com.fdmgroup.model.User;


public class UserDao {
	
	private DbConnection connection;

	public UserDao() {
		super();
		connection = DbConnection.getInstance();
	}
	
	public User create(User user){
		EntityManager em = connection.getEntityManager();
		
		em.getTransaction().begin();
			em.persist(user);
		em.getTransaction().commit();
		em.close();
		
		return user;
	}

	public void remove(User user){
		EntityManager em = connection.getEntityManager();
		User foundUser = em.find(User.class, user.getId());
		
		em.getTransaction().begin();
			em.remove(foundUser);
		em.getTransaction().commit();
		em.close();
	}

	public void update(User user){
		EntityManager em = connection.getEntityManager();
		User foundUser = em.find(User.class, user.getId());
		
		em.getTransaction().begin();
		
			if (user.getPassword() != null && !user.getPassword().equals(""))
				foundUser.setPassword(user.getPassword());
			if (user.getFirstname() != null && !user.getFirstname().equals(""))
				foundUser.setFirstname(user.getFirstname());
			if (user.getLastname() != null && !user.getLastname().equals(""))
				foundUser.setLastname(user.getLastname());

		em.getTransaction().commit();
		em.close();
	}
	
	public User findById(int id) {
		EntityManager em = connection.getEntityManager();
		User user = em.find(User.class, id);
		em.close();
		return user;
	}
	
	// FIND BY mbgID
		public User findByUserID(int findID) {
			List<User> qResult = new ArrayList<>();
			
			EntityManager em = connection.getEntityManager();
				TypedQuery<User> q = em.createNamedQuery("u.findByUserID", User.class);
				q.setParameter("uIDParam", findID);
				qResult = q.getResultList();
			em.close();
			
			if(qResult != null && qResult.size() == 1) {
				return qResult.get(0);
			}
			return null;
		}
	public User findByUsername(String username) {
		EntityManager em = connection.getEntityManager();
		TypedQuery<User> query = em.createNamedQuery("u.findByUsername", User.class);
		query.setParameter("uname", username);
		List<User> users = query.getResultList();
		em.close();
		
		if (users != null && users.size() == 1){
			return users.get(0);
		}
		
		return null;
	}
	

	// FIND ALL
		public List<User> findAll() {
			List<User> qResult = new ArrayList<>();
			
			EntityManager em = connection.getEntityManager();
				TypedQuery<User> q = em.createNamedQuery("u.findAll", User.class);
				qResult = q.getResultList();
			em.close();
			
			return qResult;
		}
	
}
