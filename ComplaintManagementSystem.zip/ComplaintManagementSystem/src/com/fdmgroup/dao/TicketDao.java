package com.fdmgroup.dao;

import javax.persistence.EntityManager;

import com.fdmgroup.model.Ticket;
import com.fdmgroup.model.User;


public class TicketDao {
	private DbConnection connection;

	public TicketDao() {
		super();
		connection = DbConnection.getInstance();
	}
	
	//add
	public void addTicket(Ticket t) {
		EntityManager em = connection.getEntityManager();
		
		em.getTransaction().begin();
			em.persist(t);
		em.getTransaction().commit();
		em.close();
	}
	
	// update
	public void update(Ticket ticket){
		EntityManager em = connection.getEntityManager();
		Ticket foundTicket = em.find(Ticket.class, ticket.getTicketId());
		
		em.getTransaction().begin();
		
			foundTicket.setTicketStatus(ticket.getTicketStatus());
				
		em.getTransaction().commit();
		em.close();
	}
	
	// find by id
	public Ticket findById(int id) {
		EntityManager em = connection.getEntityManager();
		Ticket ticket = em.find(Ticket.class, id);
		em.close();
		return ticket;
	}
}
