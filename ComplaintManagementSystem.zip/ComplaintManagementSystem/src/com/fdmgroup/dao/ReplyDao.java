package com.fdmgroup.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.fdmgroup.model.Reply;

public class ReplyDao {
	private DbConnection connection;

	public ReplyDao() {
		super();
		connection = DbConnection.getInstance();
	}
	
	//add
	public void addReply(Reply p) {
		EntityManager em = connection.getEntityManager();
		
		em.getTransaction().begin();
			em.persist(p);
		em.getTransaction().commit();
		em.close();
	}
	
	//update
//	public void updateNumber(Player p, int num) {
//		EntityManager em = connection.getEntityManager();
//
//		Player managePlayer = em.find(Player.class, p.getPlayerID());
//		
//		em.getTransaction().begin();
//		managePlayer.setJerseyNum(num);
//		
//		//em.merge(m);
//		em.getTransaction().commit();
//		em.close();
//	}

	//search by name
//public Player findByName(String n) {
//		
//		List<Player> qResult = new ArrayList<>();
//		
//		EntityManager em = connection.getEntityManager();
//			TypedQuery<Player> q = em.createNamedQuery("p.findByName", Player.class);
//			q.setParameter("pName", n);
//			qResult = q.getResultList();
//		em.close();
//		
//		if(qResult != null && qResult.size() == 1) {
//			return qResult.get(0);
//		}
//		return null;
//	}
}
