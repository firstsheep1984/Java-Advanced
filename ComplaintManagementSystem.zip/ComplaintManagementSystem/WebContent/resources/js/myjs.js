var modal = document.getElementById("loginModal");
var login = document.getElementById("login");
var span = document.getElementById("close");
var profile = document.getElementById("profile");
var bunch = document.getElementById("bunch");
var dropdown = document.getElementById("dropdown-content");
var logout = document.getElementById("logout");
var home = document.getElementById("home");

function showModal() {
    modal.style.display = "block";
}

function closeModal() {
    console.log("exiting modal");
    modal.style.display = "none";
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function drop(x) {
    console.log(x);
}

//Event Listeners and callbacks will be after lunch
window.addEventListener("resize", shrink);
window.addEventListener("load", shrink);

function shrink() {
    if (window.innerWidth < 600) {
        login.style.display = "none";
        profile.style.display = "none";
        logout.style.display = "none";
        home.style.display = "none";
        bunch.style.display = "block";
    } else {
        login.style.display = "block";
        profile.style.display = "block";
        logout.style.display = "block";
        home.style.display = "block";
        bunch.style.display = "none";
    }
    if (dropdown.style.right < 8) {
        dropdown.style.right = 8;
    }
}

// user-dashboard : close the ticket
function changeParagraph() {
    var newParagraph = "Closed";
    document.getElementById("status_word").innerHTML = newParagraph;
    /*document.getElementById("status").style.backgroundColor = "#248ea9";*/
    /*document.getElementById("status_new").style.backgroundColor = "#248ea9";*/
}

function closeTicket(ticketId){
	//changeParagraph();
	alert('You have closed this ticket!');
	document.location.href = "closeTicket?buttontype=close&id=" + ticketId;
}

/*function adminCloseTicket(ticketId){
	changeParagraph();
	alert('Admin have closed this ticket!');
	document.location.href = "closeTicket?buttontype=adminClose&id=" + ticketId;
}*/

function editTicket(ticketId){
	
	document.location.href = "editTicket?buttontype=edit&id=" + ticketId;
}

function adminEditTicket(ticketId){
	alert('admin is editng!');
	document.location.href = "editTicket?buttontype=adminEdit&id=" + ticketId;
}

/*function replyTicket(ticketId){
	
	document.location.href = "replyTicket?buttontype=reply&id=" + ticketId;
}*/

function logout() {
	  var form = document.createElement("form");
	  form.action = "./includes/logout.inc.php";
	  form.method = "post";
	  var sbmt = document.createElement("input");
	  sbmt.name = "logout-submit";
	  form.appendChild(sbmt);
	  document.body.appendChild(form);
	  form.submit();
	}